<!DOCTYPE html>
<html lang="fr-CA">
<head>
    <title>...</title>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="..." />
    <meta name="author" content="...">
    <link rel="icon" href="favicon.ico" />
    <link rel="apple-touch-icon" href="apple-touch-icon.png"/>
    <link rel="stylesheet" href="css/vendor.css">
    <link rel="stylesheet" href="css/styles.css">
    <link rel="stylesheet" href="css/ajustements.css">
</head>
<body id="top">

    <!-- page wrap
    ================================================== -->
    <div class="s-pagewrap">

        <!-- # site header
        ================================================== -->
        <header class="s-header">

             <div class="s-header__block">
                <div class="s-header__branding">
                    <p class="site-title">
                        <a href="index.php" rel="home">Scores</a>
                    </p>
                    <p class="sous-titre">La plateforme incontournable pour suivre les exploits des joueurs !<sup> <a href="#nbp1">1</a></sup></p>
                </div>
                <a class="s-header__menu-toggle" href="#"><span>Menu</span></a>
            </div> <!-- end s-header__block -->

            <div class="row s-header__nav-wrap">
                <nav class="s-header__nav">
                    <ul>
                        <li class="actif"><a href="#">Jeux</a></li>
                        <li><a href="#">Joueurs</a></li>
                        <li><a href="#">Scores</a></li>
                        <li><a href="#">À propos</a></li>
                    </ul>
                </nav> <!-- end s-header__nav -->
            </div> <!-- end s-header__nav-wrap -->

        </header> <!-- end s-header -->

        <!-- intro
        ================================================== -->
        <section class="s-intro">

                <div class="s-intro__content">
                    <div class="s-intro__text">
                        <h1 class="s-intro__text-huge">
                            Scores
                        </h1>
                    </div>
                    <div class="s-intro__bg"></div>
                </div>

        </section> <!-- end s-intro -->

        <!-- meilleurs scores
        ================================================== -->
        <section class="section">

            <div class="row">
                <div class="column">
                    <h2 class="text-pretitle">Tableau de bord</h2>
                    <p class="text-huge-title">Meilleurs scores</p>
                    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</p>
                </div>
            </div>

            <div class="scores">
                <div class="unscore"><p class="joueur">Joueur X</p><p class="lescore">1000</p><p class="jeu">Jeu A</p></div>
                <div class="unscore"><p class="joueur">Joueur Y</p><p class="lescore">987</p><p class="jeu">Jeu B</p></div>
                <div class="unscore"><p class="joueur">Joueur Z</p><p class="lescore">836</p><p class="jeu">Jeu C</p></div>
            </div>

        </section> <!-- end meilleurs scores -->

        <!-- # deuxième section
        ================================================== -->
        <section class="section contraste">

            <div class="row">
                <div class="column lg-12">
                    <h2 class="text-pretitle">Sous-titre</h2>

                    <p class="text-huge-title">
                    Titre
                    </p>
                </div>
            </div>

            <div class="row">
                <div class="column">
                    Texte colonne 1
                </div> <!-- end column -->
                <div class="column">
                    Texte colonne 2
                </div> <!-- end column -->
            </div> <!-- end row -->

        </section>

        <!-- # site footer
        ================================================== -->
        <footer id="colophon" class="s-footer">

            <div class="row s-footer__bottom">
                <div class="column ss-copyright">
                    <p>Maquette par <a href="https://www.styleshout.com/">StyleShout</a>, 2022</p>
                    <p id="nbp1">1. Slogan généré par OpenAI. (2023). ChatGPT (version 30 novembre 2022) [Modèle massif de langage]. <a href="https://chat.openai.com/chat" target="_blank">https://chat.openai.com/chat</a></p>
                </div>
            </div> <!-- end s-footer__bottom-->

        </footer> <!-- end s-footer -->

    </div> <!-- end s-pagewrap -->

</body>
</html>
