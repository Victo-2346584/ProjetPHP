<?php
require "./include/configuration.inc";
require "./include/entete.inc"
?>
    <section class="couleur3 section contraste">

        <div class="row">
            <div class="column lg-12">
                <h2 class="text-pretitle">nthyhy</h2>

                <p class="text-huge-title">
                    Maintien des scores
                </p>
            </div>
        </div>

        <div class="row">
            <div class="column">
                Je suis québécois, je suis étudiant en informatique.
            </div> <!-- end column -->
            <div class="column">
                Ce site maintient les scores enregistrés.
            </div> <!-- end column -->
            <div class="column">
                <img class="image" src="medias/commun/20240131_113029.webp" width="180px">
            </div> <!-- end column -->
            <div class="column">
                <a href="https://facebook.com"><i class="fa-brands fa-facebook"></i></a>
                <a href="https://instagram.com"><i class="fa-brands fa-instagram"></i></a>
            </div> <!-- end column -->
        </div> <!-- end row -->
    </section>
<?php
require "./include/pieds_de_page.inc";
require "./include/nettoyage.inc";

