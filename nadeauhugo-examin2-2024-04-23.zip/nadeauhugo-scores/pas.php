<?php
require "./include/entete.inc";
?>
    <section class="couleur1 s-intro">

        <div class="s-intro__content">
            <p>l'enregistrement cest bien passe mais pas de courriel envoyer</p>
        </div>

    </section> <!-- end s-intro -->

<?php
require "./include/pieds_de_page.inc";