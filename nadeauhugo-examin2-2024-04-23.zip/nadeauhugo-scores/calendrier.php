<?php
require "./include/configuration.inc";
require "./include/entete.inc"
?>

    <!-- intro
       ================================================== -->

    <section class="couleur1 Calendrier">

        <h2> Frévrier 2024</h2>
        <table>
            <tr>
                <th>Lun</th>
                <th>Mar</th>
                <th>Mer</th>
                <th>Jeu</th>
                <th>Ven</th>
                <th>Sam</th>
                <th>Dim</th>
            </tr>
            <tr>
                <td></td>
                <td></td>
                <td></td>
                <td> 01</td>
                <td>02</td>
                <td> 03</td>
                <td> 04</td>
            </tr>
            <tr>
                <td> 05</td>
                <td> 06</td>
                <td> 07</td>
                <td> 08</td>
                <td>09</td>
                <td> 10</td>
                <td> 11</td>
            </tr>
            <tr>
                <td> 12</td>
                <td> 13</td>
                <td> 14 <p>1500 jeux A</p></td>
                <td> 15</td>
                <td>16</td>
                <td> 17</td>
                <td> 18</td>
            </tr>
            <tr>
                <td> 19</td>
                <td> 20</td>
                <td> 21</td>
                <td> 22</td>
                <td> 23</td>
                <td> 24</td>
                <td> 25</td>
            </tr>
            <tr>
                <td> 26</td>
                <td> 27</td>
                <td> 28</td>
                <td> 08</td>
                <td></td>
                <td></td>
                <td></td>
            </tr>


        </table>
    </section>
    <!-- intro
    ================================================== -->
    <section class=" couleur3 section contraste">

        <div class="row">
            <div class="column lg-12">
                <h2 class="text-pretitle">Hugo</h2>

                <p class="text-huge-title">
                    maintient des scores
                </p>
            </div>
        </div>

        <div class="row">
            <div class="column">
                je suis québecois, je suis etudiant en informatique.
            </div> <!-- end column -->
            <div class="column">
                ce site maintient les scores enregistrer
            </div> <!-- end column -->
            <div class="image">
                <img class="image" src="medias/commun/20240131_113029.jpg" alt="">
            </div>
        </div> <!-- end row -->

    </section>

<?php
require "./include/pieds_de_page.inc";
require "./include/nettoyage.inc";