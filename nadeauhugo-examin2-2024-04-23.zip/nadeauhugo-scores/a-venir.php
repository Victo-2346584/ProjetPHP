<?php
require "./include/configuration.inc";
require "./include/entete.inc"
?>


<?php
$query = "SELECT id, description FROM tableinexistante"
;

$result = $mysqli->query($query);

if ($result ==null){
    echo_debug("la selection est null");
}
else if ($result->num_rows > 0) {
// sorte les lignes et les mets dans le bon format
    echo '<div class="scores">';
    while($row = $result->fetch_assoc()) {
        echo '<div class="unscore anime"><p class="joueur">' . $row["joueur"] . '</p><p class="lescore">' . $row["lescore"] . '</p><i class="fa-solid fa-star"></i><p>10 janvier 2024</p><p class="jeu">' . $row["jeu"] . '</p></div>';
    }
    echo '</div>';
} else {
    echo "0 results";
}
?>
    <!-- meilleurs scores
    ================================================== -->
    <!--  <section class="couleur2 section">

        <div class="row">
            <div class="column">
                <h2 class="text-pretitle">Tableau de bord</h2>
                <p class="text-huge-title">Meilleurs scores</p>
                <p>Le site est important pour afficher les scores des joueurs. Ils est surtout important, car il va me donner une note</p>
            </div>
        </div>

        <div class="scores">
            <div class="unscore"><p class="joueur">Joueur X</p><p class="lescore">1000</p><i class="fa-solid fa-star"></i><p class="jeu">Jeu A</p></div>
            <div class="unscore"><p class="joueur">Joueur Y</p><p class="lescore">987</p><i class="fa-solid fa-star"></i><p class="jeu">Jeu B</p></div>
            <div class="unscore"><p class="joueur">Joueur Z</p><p class="lescore">836</p><i class="fa-solid fa-star"></i><p class="jeu">Jeu C</p></div>
        </div>

    </section>  end meilleurs scores -->

    <!-- # deuxième section
    ================================================== -->
    <section class=" couleur3 section contraste">

        <div class="row">
            <div class="column lg-12">
                <h2 class="text-pretitle">nthyhy</h2>

                <p class="text-huge-title">
                    maintient des scores
                </p>
            </div>
        </div>

        <div class="row">
            <div class="column">
                je suis québecois, je suis etudiant en informatique.
            </div> <!-- end column -->
            <div class="column">
                ce site maintient les scores enregistrer
            </div> <!-- end column -->
            <div class="image">
                 <img class="image" src="medias/commun/20240131_113029.jpg">
            </div>
            <div>
                <a href="facebook.com"><i class="fa-brands fa-facebook"></i></a>
                <a href="instagram.com"><i class="fa-brands fa-instagram"></i></a>
                <div> <!-- end row -->

    </section>

<?php
require "./include/pieds_de_page.inc";
require "./include/nettoyage.inc";

