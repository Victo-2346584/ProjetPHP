<?php
/**
 * user: hugon
 * date: 2024-01-23
 * Time: 16:18
 */
?>
<!DOCTYPE html>
<html lang="fr-CA">
    <body>
        <?php
            echo '<p>Configurations actives :</p>';
            phpinfo();
        ?>
    </body>
</html>
